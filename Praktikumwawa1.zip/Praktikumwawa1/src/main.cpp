#include <Arduino.h>

int RED_LIGHT=17;
int YELLOW_LIGHT=18;
int GREEN_LIGHT=19;

void setup() {
  pinMode(RED_LIGHT, OUTPUT);
  pinMode(YELLOW_LIGHT, OUTPUT);
  pinMode(GREEN_LIGHT, OUTPUT);
}

void loop() {
  // Lampu merah menyala selama 30 detik
  digitalWrite(RED_LIGHT, HIGH);
  digitalWrite(YELLOW_LIGHT, LOW);
  digitalWrite(GREEN_LIGHT, LOW);
  Serial.println("Lampu Merah");
  delay(30000);

  // Lampu kuning menyala selama 5 detik
  digitalWrite(RED_LIGHT, LOW);
  digitalWrite(YELLOW_LIGHT, HIGH);
  digitalWrite(GREEN_LIGHT, LOW);
  Serial.println("Lampu Kuning");
  delay(5000);
  
  // Lampu hijau menyala selama 20 detik
  digitalWrite(RED_LIGHT, LOW);
  digitalWrite(YELLOW_LIGHT, LOW);
  digitalWrite(GREEN_LIGHT, HIGH);
  Serial.println("Lampu Hijau");
  delay(20000);
}